const dummyData = [
  { keyword: "snowboard", volume: 605000, kd: 67, cpc: 0.52, trend: "Last week" },
  { keyword: "burton snowboard", volume: 21700, kd: 62, cpc: 0.89, trend: "Last week" },
  { keyword: "burton snowboards", volume: 12100, kd: 61, cpc: 0.72, trend: "Last week" },
  { keyword: "capita snowboards", volume: 9900, kd: 59, cpc: 0.67, trend: "Last week" },
  { keyword: "jones snowboards", volume: 9900, kd: 60, cpc: 0.58, trend: "Last week" },
];

function searchKeyword() {
  const searchInput = document.getElementById("searchInput").value.toLowerCase();
  const volMin = parseInt(document.getElementById("volumeMin").value) || 0;
  const volMax = parseInt(document.getElementById("volumeMax").value) || Infinity;
  const cpcMin = parseFloat(document.getElementById("cpcMin").value) || 0;
  const cpcMax = parseFloat(document.getElementById("cpcMax").value) || Infinity;
  const kdMin = parseInt(document.getElementById("kdMin").value) || 0;
  const kdMax = parseInt(document.getElementById("kdMax").value) || 100;

  const filtered = dummyData.filter(item =>
    item.keyword.toLowerCase().includes(searchInput) &&
    item.volume >= volMin && item.volume <= volMax &&
    item.cpc >= cpcMin && item.cpc <= cpcMax &&
    item.kd >= kdMin && item.kd <= kdMax
  );

  const tableBody = document.getElementById("resultTable");
  tableBody.innerHTML = "";

  filtered.forEach(item => {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${item.keyword}</td>
      <td>${item.volume}</td>
      <td>${item.kd}</td>
      <td>$${item.cpc.toFixed(2)}</td>
      <td>${item.trend}</td>
    `;
    tableBody.appendChild(row);
  });
}
